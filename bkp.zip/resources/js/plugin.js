import "../css/plugin.css";
import "@disciple.tools/web-components";

console.log('plugin.js')