import "../css/admin.css";
import "@disciple.tools/web-components";

console.log('admin.js')